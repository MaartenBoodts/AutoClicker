package util;

import gui.AutoClickerFrame;

import java.awt.*;
import java.util.ArrayList;

public class AutoClicker {

    private Robot robot;
    private ArrayList<Operation> commandList;

    private int loopAmount = 1;
    private boolean stopLooping = false;

    private AutoClickerFrame autoClickerFrame;

    public AutoClicker() {

        try {
            robot = new Robot();
        } catch (AWTException e) {
            System.out.println("Failed starting Robot. Exiting program");
            System.exit(-1);
        }

        commandList = new ArrayList<>();
        autoClickerFrame = new AutoClickerFrame(this);
    }

    public void setAutoDelay(int ms) {
        robot.setAutoDelay(ms);
    }

    public void addDelay(int ms) {
        Operation operation = new Operation(OperationTypeEnum.DELAY);
        operation.setDelay(ms);

        commandList.add(operation);
    }

    public void addMouseMove(int x, int y) {
        Operation operation = new Operation(OperationTypeEnum.MOUSEMOVE);
        operation.setX(x);
        operation.setY(y);

        commandList.add(operation);
    }

    public void addMousePress(int buttons) {
        Operation operation = new Operation(OperationTypeEnum.MOUSEPRESS);
        operation.setButtons(buttons);

        commandList.add(operation);
    }

    public void addMouseRelease(int buttons) {
        Operation operation = new Operation(OperationTypeEnum.MOUSERELEASE);
        operation.setButtons(buttons);

        commandList.add(operation);
    }

    public void addMouseWheel(int wheelAmt) {
        Operation operation = new Operation(OperationTypeEnum.MOUSEWHEEL);
        operation.setWheelAmt(wheelAmt);

        commandList.add(operation);
    }

    public void addKeyPress(int keyCode) {
        Operation operation = new Operation(OperationTypeEnum.KEYPRESS);
        operation.setKeyCode(keyCode);

        commandList.add(operation);
    }

    public void addKeyRelease(int keyCode) {
        Operation operation = new Operation(OperationTypeEnum.KEYRELEASE);
        operation.setKeyCode(keyCode);

        commandList.add(operation);
    }

    public void addScreenCapture() {
        Operation operation = new Operation(OperationTypeEnum.SCREENCAPTURE);

        commandList.add(operation);
    }

    public void addScreenCapture(int startX, int startY, int endX, int endY) {
        Operation operation = new Operation(OperationTypeEnum.SCREENCAPTURE);

        operation.setStartX(startX);
        operation.setStartY(startY);
        operation.setEndX(endX);
        operation.setEndY(endY);

        commandList.add(operation);
    }

    public void setLoopAmount(int loopAmount) {
        this.loopAmount = loopAmount;
    }

    public void setStopLooping(boolean stopLooping) {
        this.stopLooping = stopLooping;
    }

    public OperationTypeEnum getOperationType(int index) {
        Operation operation = getOperation(index);

        if (operation != null) {
            return operation.getOperationTypeEnum();
        } else {
            return null;
        }
    }

    public void updateDelay(int index, int ms) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.DELAY);

        operation.setDelay(ms);

        commandList.remove(index);
        commandList.add(index, operation);
    }

    public void updateMouseMove(int index, int x, int y) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.MOUSEMOVE);

        operation.setX(x);
        operation.setY(y);

        commandList.remove(index);
        commandList.add(index, operation);
    }

    public void updateMousePress(int index, int buttons) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.MOUSEPRESS);

        operation.setButtons(buttons);

        commandList.remove(index);
        commandList.add(index, operation);

    }

    public void updateMouseRelease(int index, int buttons) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.MOUSERELEASE);

        operation.setButtons(buttons);

        commandList.remove(index);
        commandList.add(index, operation);

    }

    public void updateMouseWheel(int index, int wheelAmt) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.MOUSEWHEEL);

        operation.setWheelAmt(wheelAmt);

        commandList.remove(index);
        commandList.add(index, operation);

    }

    public void updateKeyPress(int index, int keyCode) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.KEYPRESS);

        operation.setKeyCode(keyCode);

        commandList.remove(index);
        commandList.add(index, operation);

    }


    public void updateKeyRelease(int index, int keyCode) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.KEYRELEASE);

        operation.setKeyCode(keyCode);

        commandList.remove(index);
        commandList.add(index, operation);

    }

    public void updateScreenCapture(int index) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.SCREENCAPTURE);

        operation.setCaptureFullScreen(true);

        commandList.remove(index);
        commandList.add(index, operation);

    }

    public void updateScreenCapture(int index, int startX, int startY, int endX, int endY) {
        Operation operation = commandList.get(index);
        operation.setOperationTypeEnum(OperationTypeEnum.SCREENCAPTURE);

        operation.setStartX(startX);
        operation.setStartY(startY);
        operation.setEndX(endX);
        operation.setEndY(endY);

        commandList.remove(index);
        commandList.add(index, operation);

    }

    public void switchOperations(int startIndex, int destinationIndex) {
        Operation operation = getOperation(startIndex);

        commandList.add(destinationIndex, operation);
        commandList.remove(startIndex + 1);
    }

    public void start() {
        stopLooping = false;

        for (int i = 0; i < loopAmount && !stopLooping; i++) {
            for (int y = 0; y < commandList.size() && !stopLooping; y++) {
                autoClickerFrame.selectListAction(y);
                executeOperation(commandList.get(y));
            }
        }
    }

    public ArrayList<Operation> getCommandList() {
        return commandList;
    }

    private void executeOperation(Operation operation) {
        switch (operation.getOperationTypeEnum()) {
            case DELAY:
                robot.delay(operation.getDelay());
                break;
            case MOUSEMOVE:
                robot.mouseMove(operation.getX(), operation.getY());
                break;
            case MOUSEPRESS:
                robot.mousePress(operation.getButtons());
                break;
            case MOUSERELEASE:
                robot.mouseRelease(operation.getButtons());
                break;
            case MOUSEWHEEL:
                robot.mouseWheel(operation.getWheelAmt());
                break;
            case KEYPRESS:
                robot.keyPress(operation.getKeyCode());
                break;
            case KEYRELEASE:
                robot.keyRelease(operation.getKeyCode());
                break;
            case SCREENCAPTURE:

                if (operation.isCaptureFullScreen()) {
                    robot.createScreenCapture();
                } else {
                    robot.createScreenCapture(operation.getStartX(), operation.getStartY(), operation.getEndX(), operation.getEndY());
                }
                break;
            default:
                System.out.println("Error: Unknown operation!");
                break;
        }
    }

    private Operation getOperation(int index) {
        try {
            return commandList.get(index);
        } catch (NullPointerException e) {
            System.out.println("Operation index not found!");
            return null;
        }
    }
}
