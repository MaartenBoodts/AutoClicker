package util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;

public class Robot extends java.awt.Robot implements Runnable {

    public Robot() throws AWTException {
        super();

    }

    public void createScreenCapture(int startX, int startY, int endX, int endY) {
        saveImage(super.createScreenCapture(new Rectangle(startX, startY, (endX - startX), (endY - startY))));
    }

    public void createScreenCapture() {
        saveImage(super.createScreenCapture(getFullScreenSize()));
    }

    private boolean saveImage(BufferedImage image) {

        Calendar calendar = Calendar.getInstance();

        File file = new File(calendar.get(Calendar.DAY_OF_MONTH)
                + "-" + calendar.get(Calendar.MONTH)
                + "-" + calendar.get(Calendar.YEAR)
                + "_" + calendar.get(Calendar.HOUR_OF_DAY)
                + "-" + calendar.get(Calendar.MINUTE)
                + "-" + calendar.get(Calendar.SECOND)
                + ".png");

        try {
            ImageIO.write(image, "png", file);
            return true;

        } catch (IOException e) {

            return false;
        }
    }

    private Rectangle getFullScreenSize() {

        int width = 0;
        int height = 0;

        System.out.println();
        for (GraphicsDevice graphicsDevice : GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices()) {
            for (GraphicsConfiguration graphicsConfiguration : graphicsDevice.getConfigurations()) {

                int x = graphicsConfiguration.getBounds().width;
                int y = graphicsConfiguration.getBounds().height;

                if (width != x) {
                    width = +x;
                }

                if (height != y) {
                    height = +y;
                }
            }
        }

        return new Rectangle(0, 0, width, height);
    }

    @Override
    public void run() {

    }
}
