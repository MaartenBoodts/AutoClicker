package util;

public enum  OperationTypeEnum {

    DELAY(0),
    MOUSEMOVE(1),
    MOUSEPRESS(2),
    MOUSERELEASE(3),
    MOUSEWHEEL(4),
    KEYPRESS(5),
    KEYRELEASE(6),
    SCREENCAPTURE(7);

    private int typeId;

    OperationTypeEnum(int typeId){
        this.typeId = typeId;
    }

    public int getTypeId() {
        return typeId;
    }

    @Override
    public String toString() {
        return this.name().substring(0, 1) + this.name().substring(1).toLowerCase();
    }
}
