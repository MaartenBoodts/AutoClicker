package test;

import util.AutoClicker;

public class TestAutoClicker{


    public static void main(String[] args) {

        AutoClicker autoClicker = new AutoClicker();
    }

}
